﻿
using System;
class generator
{

	// Функция для генерации всего
	// простые числа меньше n
	static void SieveOfEratosthenes(int n,
									bool[] isPrime)
	{
		// Инициализируем все записи bool
		// массив как истина. Значение в
		// isPrime [i] окончательно будет ложным
		// если i не простое число, иначе верно
		// bool isPrime [n + 1];
		isPrime[0] = isPrime[1] = false;
		for (int i = 2; i <= n; i++)
			isPrime[i] = true;

		for (int p = 2; p * p <= n; p++)
		{
			// Если isPrime [p] не изменилось,
			// тогда это простое число
			if (isPrime[p] == true)
			{
				// Обновляем все кратные p
				for (int i = p * 2; i <= n; i += p)
					isPrime[i] = false;
			}
		}
	}

	// Функция для печати простого числа
	// пара с данным продуктом
	static void findPrimePair(int n)
	{
		int flag = 0;

		// Генерация простых чисел с помощью Sieve
		bool[] isPrime = new bool[n + 1];
		SieveOfEratosthenes(n, isPrime);

		// Обходим все числа до

		for (int i = 2; i < n; i++)
		{
			int x = n / i;

			if (isPrime[i] && isPrime[x] &&
					x != i && x * i == n)
			{
				Console.Write(i + " " + x);
				flag = 1;
				return;
			}
		}
		//ПАРЫ НЕ НАЙДЕНЫ
		if (flag == 0)
			Console.Write("NO PAIR FOUND");
	}


	public static void Main()
	{
		Console.WriteLine("ENTER A RANDOM NUMBER: ");
		int n = Convert.ToInt32(Console.ReadLine());
		

		findPrimePair(n);
	}
}


